require("dotenv").config();
require = require("esm")(module);
module.exports = require("./server.js");
